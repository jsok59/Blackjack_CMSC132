package blackjack;
import java.util.*;

public class Blackjack implements BlackjackEngine {
	
	/**
	 * Constructor you must provide.  Initializes the player's account 
	 * to 200 and the initial bet to 5.  Feel free to initialize any other
	 * fields. Keep in mind that the constructor does not define the 
	 * deck(s) of cards.
	 * @param randomGenerator
	 * @param numberOfDecks
	 */
	

	private ArrayList<Card> myCards;
	private int numCards;
	private int numberOfDecks;
	private Random randomGenerator;
	private ArrayList<Card> playerCards;
	private ArrayList<Card> dealerCards;
	private int gameStatus;
	private int account = 200;
	private int bet = 5;
	private int current = 0;
	
	public Blackjack(Random randomGenerator, int numberOfDecks) {
		this.numberOfDecks = numberOfDecks;
		this.randomGenerator = randomGenerator;
		this.numCards = numberOfDecks * 52;
		
	}
	
	public int getNumberOfDecks() {
		return this.numberOfDecks;
	}
	
	public void createAndShuffleGameDeck() {
		this.myCards = new ArrayList<Card>(this.numCards);
		for (int d = 0; d < numberOfDecks; d++) {
			
			for(int s = 0; s < 4; s++) {
				
				for(int n = 0; n < 13; n ++) {
					Card newCard = new Card(CardValue.values()[n], CardSuit.values()[s]);
					this.myCards.add(newCard);
					
				}
			}
		}
		
		Collections.shuffle(myCards, randomGenerator);
		
		
	}
	
	
	public Card[] getGameDeck() {
		Card gameDeck [] = new Card[myCards.size()];
		for (int i = 0; i < myCards.size(); i ++) {
			gameDeck[i] = myCards.get(i);
		}
		return gameDeck;
	}
	
	public void deal() {	
		this.myCards = new ArrayList<Card>(this.numCards);
		for (int d = 0; d < numberOfDecks; d++) {
			
			for(int s = 0; s < 4; s++) {
				
				for(int n = 0; n < 13; n ++) {
					Card newCard = new Card(CardValue.values()[n], CardSuit.values()[s]);
					this.myCards.add(newCard);
					
				}
			}
		}
		
		Collections.shuffle(myCards, randomGenerator);  
		playerCards = new ArrayList<Card>();
		dealerCards = new ArrayList<Card>();

		playerCards.add(myCards.get(0));
		myCards.remove(0);
		myCards.get(0).setFaceDown();
		dealerCards.add(myCards.get(0));
		myCards.remove(0);
		playerCards.add(myCards.get(0));
		myCards.remove(0);
		dealerCards.add(myCards.get(0));
		myCards.remove(0);

		this.gameStatus = GAME_IN_PROGRESS;
		
		account = account - bet;
		
	}
		
	public Card[] getDealerCards() {
		Card dealer [] = new Card [dealerCards.size()];
		for (int i = 0; i < dealerCards.size(); i++) {
			dealer[i] = dealerCards.get(i);
		}
		return dealer;
	}

	public int[] getDealerCardsTotal() {
		int total = 0;
		int aceCount = 0;
		int totalwithAce = 0;
		ArrayList<Integer> cardtotal = new ArrayList<Integer>();
		int playerCardsTotal[] = null;
		for (int i = 0; i < dealerCards.size(); i++) {
			total = total + dealerCards.get(i).getValue().getIntValue();
		}
		
		
		for (int i = 0; i < dealerCards.size(); i++) {
			if (dealerCards.get(i).getValue().getValue() == "1")
				aceCount++;
		}
		
		if (aceCount == 0 && total <= 21) {
			playerCardsTotal = new int [1];
			playerCardsTotal [0] = total;
			return playerCardsTotal;
		}
		else if (total > 21)
			return playerCardsTotal;
		else
		{
			cardtotal.add(total);
			for (int i = 0; i < aceCount; i++) {
				totalwithAce = total + 10 * (i+1);
					if (totalwithAce <= 21) {
						cardtotal.add(totalwithAce);
					}
						
			}
			playerCardsTotal = new int[cardtotal.size()];
			for(int i = 0; i < cardtotal.size(); i++) {
				playerCardsTotal[i]= cardtotal.get(i);
			}
				
			return playerCardsTotal;
		}

	}

	public int getDealerCardsEvaluation() {
		
		int Ace1 = dealerCards.get(0).getValue().getIntValue();
		int Ace2 = dealerCards.get(1).getValue().getIntValue();
		int total [];
		total = getDealerCardsTotal();
		
		int max = 0;
		if (getDealerCardsTotal() == null)
			
			return BUST;
		else {
			
			for(int i = 0; i < total.length; i++)
				if(total[i] > max)
					max = total[i];
			
		
	
		if (max < 21)
			return LESS_THAN_21;

		else if (dealerCards.size() == 2 && ((Ace1 == 1 && Ace2 == 10) || (Ace1 == 10 && Ace2 == 1))){
			return BLACKJACK;
		}
		else
			return HAS_21;
		}

	}
	
	public Card[] getPlayerCards() {
		Card player [] = new Card [playerCards.size()];
		for (int i = 0; i < playerCards.size(); i++) {
			player[i] = playerCards.get(i);
		}
		return player;
	}
	

	public int[] getPlayerCardsTotal() {
		int total = 0;
		int aceCount = 0;
		int totalwithAce = 0;
		ArrayList<Integer> cardtotal = new ArrayList<Integer>();
		int playerCardsTotal[] = null;
		for (int i = 0; i < playerCards.size(); i++) {
			total = total + playerCards.get(i).getValue().getIntValue();
		}
		
		
		for (int i = 0; i < playerCards.size(); i++) {
			if (playerCards.get(i).getValue().getValue() == "1")
				aceCount++;
		}
		
		if (aceCount == 0 && total <= 21) {
			playerCardsTotal = new int [1];
			playerCardsTotal [0] = total;
			return playerCardsTotal;
		}
		else if (total > 21)
			return playerCardsTotal;
		else
		{
			cardtotal.add(total);
			for (int i = 0; i < aceCount; i++) {
				totalwithAce = total + 10 * (i+1);
					if (totalwithAce <= 21) {
						cardtotal.add(totalwithAce);
					}
						
			}
			playerCardsTotal = new int[cardtotal.size()];
			for(int i = 0; i < cardtotal.size(); i++) {
				playerCardsTotal[i]= cardtotal.get(i);
			}
				
			return playerCardsTotal;
		}

	}
		
	public int getPlayerCardsEvaluation() {
		
		
		int Ace1 = playerCards.get(0).getValue().getIntValue();
		int Ace2 = playerCards.get(1).getValue().getIntValue();
		int total [];
		total = getPlayerCardsTotal();
		int max = 0;
		if (getPlayerCardsTotal() == null)
			return BUST;
		else {
			
		
			for(int i = 0; i < total.length; i++)
				if(total[i] > max)
					max = total[i];
		

		if (max < 21)
			return LESS_THAN_21;
		else if (playerCards.size() == 2 && (Ace1 == 1 && Ace2 == 10) || (Ace1 == 10 && Ace2 == 1)) {
			return BLACKJACK;
		}
		else
			return HAS_21;
		}
	}
	
	public void playerHit() {
		playerCards.add(myCards.get(0));
		myCards.remove(0);
		
		if (getPlayerCardsTotal() == null )
			gameStatus = DEALER_WON;
		else
			gameStatus = GAME_IN_PROGRESS;
	}
	
	public void playerStand() {
		dealerCards.get(0).setFaceUp();
		int totalD [];
		totalD = getDealerCardsTotal();
		
		int maxD = totalD[0];
		for(int i = 1; i < totalD.length; i++)
			if(totalD[i] > maxD)
				maxD = totalD[i];
		
		int totalP [];
		totalP = getPlayerCardsTotal();
		int maxP = totalP[0];
			for(int i = 1; i < totalP.length; i++)
				if(totalP[i] > maxP)
					maxP = totalP[i];
		int currentD = 2;
		
		while(maxD < 16 && maxD < maxP) {
		
			dealerCards.add(myCards.get(0));
			myCards.remove(0);
			maxD = maxD + dealerCards.get(currentD).getValue().getIntValue();
			currentD ++;
			
		}
		if (maxD > 21) {
			gameStatus = PLAYER_WON;
			account = account + bet*2;
		}
		else if (maxD == maxP) {
			gameStatus = DRAW;
			account = account + bet;
		}
		else if(maxD > maxP)
			gameStatus = DEALER_WON;
		else{
			gameStatus = PLAYER_WON;
			account = account + bet*2;
		}
	}
			
			
		
		
		
	
	public int getGameStatus() {
		return gameStatus;
	}
		
	public void setBetAmount(int amount) {
		this.bet = amount;
	}
	
	public int getBetAmount() {
		return bet;
	}
	
	public void setAccountAmount(int amount) {	
		this.account = amount;
	}
	
	public int getAccountAmount() {
		return account;
	}
	
	/* Feel Free to add any private methods you might need */
}